
package com.empty.enpty;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.util.LogF;


public class MainActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.empty_activity_main);
		
		LogF.d("MainActivity", "LogF.d()");
	}
	
	public void a(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5,
			int paramInt)
	{
		showLog(paramLong1);
	}
	
	public static void showLog(long paramLong1)
	{
		Log.e("接收到的时间值为：", paramLong1 + "");
	}
}
