
package android.util;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;


//invoke-static {v3, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
/** LogF.java: 
 * 替换 所有 Landroid/util/Log; 为 Landroid/util/LogF; 
 * 
 * ----- 2019-5-15 下午4:09:55 wangzhongyuan */
public class LogF
{
	public static final int ASSERT = Log.ASSERT;
	public static final int DEBUG = Log.DEBUG;
	public static final int ERROR = Log.ERROR;
	public static final int INFO = Log.INFO;
	public static final int VERBOSE = Log.VERBOSE;
	public static final int WARN = Log.WARN;
	
	public static int d(String tag, String msg)
	{
		ShowText("D: " + tag, msg);
		if(ShowLogCat) return Log.d(tag, msg);
		else return 8;
	}
	
	public static int d(String tag, String msg, Throwable tr)
	{
		ShowText("D: " + tag, msg + "\r\n" + tr.toString());
		if(ShowLogCat) return Log.d(tag, msg, tr);
		else return 8;
	}
	
	public static int e(String tag, String msg)
	{
		ShowText("E: " + tag, msg);
		if(ShowLogCat) return Log.e(tag, msg);
		else return 8;
	}
	
	public static int e(String tag, String msg, Throwable tr)
	{
		ShowText("E: " + tag, msg + "\r\n" + tr.toString());
		if(ShowLogCat) return Log.e(tag, msg, tr);
		else return 8;
	}
	
	public static String getStackTraceString(Throwable tr)
	{
		String str = Log.getStackTraceString(tr);
		if(ShowLogCat) ShowText("StackTrace: ", str);
		return str;
	}
	
	public static int i(String tag, String msg)
	{
		ShowText("I: " + tag, msg);
		if(ShowLogCat) return Log.i(tag, msg);
		else return 8;
	}
	
	public static int i(String tag, String msg, Throwable tr)
	{
		ShowText("I: " + tag, msg + "\r\n" + tr.toString());
		if(ShowLogCat) return Log.i(tag, msg, tr);
		else return 8;
	}
	
	public static boolean isLoggable(String tag, int level)
	{
		ShowText("isLoggable: " + tag, level + "");
		if(ShowLogCat) return Log.isLoggable(tag, level);
		else return false;
	}
	
	public static int println(int priority, String tag, String msg)
	{
		ShowText("println: " + tag, msg);
		if(ShowLogCat) return Log.println(priority, tag, msg);
		else return 8;
	}
	
	public static int v(String tag, String msg)
	{
		ShowText("V: " + tag, msg);
		if(ShowLogCat) return Log.v(tag, msg);
		else return 8;
	}
	
	public static int v(String tag, String msg, Throwable tr)
	{
		ShowText("V: " + tag, msg + "\r\n" + tr.toString());
		if(ShowLogCat) return Log.v(tag, msg, tr);
		else return 8;
	}
	
	public static int w(String tag, String msg)
	{
		ShowText("W: " + tag, msg);
		if(ShowLogCat) return Log.w(tag, msg);
		else return 8;
	}
	
	public static int w(String tag, Throwable tr)
	{
		ShowText("W: " + tag, tr.toString());
		if(ShowLogCat) return Log.w("W: " + tag, tr);
		else return 8;
	}
	
	public static int w(String tag, String msg, Throwable tr)
	{
		ShowText("W: " + tag, msg + "\r\n" + tr.toString());
		if(ShowLogCat) return Log.w(tag, msg, tr);
		else return 8;
	}
	
	public static int wtf(String tag, String msg)
	{
		ShowText("wtf: " + tag, msg);
		if(ShowLogCat) return Log.wtf(tag, msg);
		else return 8;
	}
	
	public static int wtf(String tag, String msg, Throwable tr)
	{
		ShowText("wtf: " + tag, msg + "\r\n" + tr.toString());
		if(ShowLogCat) return Log.wtf(tag, msg, tr);
		else return 8;
	}
	
	public static int wtf(String tag, Throwable tr)
	{
		ShowText("wtf: " + tag, tr.toString());
		if(ShowLogCat) return Log.wtf(tag, tr);
		else return 8;
	}
	
	// ---------------------------------------------------------------------
	
	public static boolean ShowFileLog = true;	// 输出log信息至文件
	public static boolean ShowLogCat = true;	// 输出logCat信息
	
	
	public static void ShowText(final String tag, final String msg)
	{
		if (ShowFileLog)
		{
			new Handler(Looper.getMainLooper()).post(new Runnable()
			{
				@Override
				public void run()
				{
					// Toast.makeText(getActivity().getApplicationContext(), info, Toast.LENGTH_SHORT).show();
					// Log.d(tag, msg);
					
					String info = tag + ", " + msg;
					FileLog(info);	// 输出log到文件
				}
			});
		}
	}

	
	/** 输出log信息到文件中 */
	public static String FileLog(String info)
	{
		if (ShowFileLog)
		{
			String crashPath = "/sdcard/FileLog/";
			
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String date = formatter.format(new Date());
			
			DateFormat formatter2 = new SimpleDateFormat("HH:mm:ss");
			String time = formatter2.format(new Date()) + "  ";
			
			String fileName = "log-" + date + ".txt";
			info = "\r\n" + time + info;
			
			try
			{
				if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
				{
					// String path = "/sdcard/com.hm.pay.demo/crash/";
					File dir = new File(crashPath);
					if (!dir.exists())
					{
						dir.mkdirs();
					}
					FileOutputStream fos = new FileOutputStream(crashPath + fileName, true);
					fos.write(info.getBytes());
					fos.close();
				}
			}
			catch (Exception e)
			{
				Log.e("LogF", "an error occured while writing file log...", e);
			}
			return crashPath + fileName;
		}
		else return "";
	}
	
}
